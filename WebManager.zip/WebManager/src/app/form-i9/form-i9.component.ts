import { Component, OnInit } from '@angular/core';
import {NewFormDto,UploadFile} from './newFormDto'
import {CreateFormService} from '../shared/services/createform.service'
@Component({
  selector: 'form-i9',
  templateUrl: './form-i9.component.html',
  styleUrls: ['./form-i9.component.css']
})
export class FormI9Component implements OnInit {
  private createFormService:CreateFormService;
   public errorMsg : string;
  private newForm :NewFormDto ={LastName :null,FirstName:null,MiddleName:null,Address:null,Upload:null};
  constructor(createForm:CreateFormService) { 
    this.createFormService = createForm;
  }

  ngOnInit() {
  }
  onFileChanged(event){
   let file = event.target.files[0];
   let reader = new FileReader();
   let fileData  =  reader.readAsDataURL(file);
   reader.onload =() =>{
     let uploadingFile : UploadFile={FileName :file.name,Filetype :file.type ,Value:reader.result.split(',')[1]}
     this.newForm.Upload=uploadingFile;
   }
   
  }
  create(){
    
      console.log(this.newForm.Upload);
      console.log(this.newForm);
     this.createFormService.create(this.newForm)
    .subscribe(
      data => {
        let token = data;
        if(token != null){
          this.errorMsg = "Sucess";
        }else{
          this.errorMsg = "Please check the username and password";
        }
      }
    );
  }
}
