interface INewForm{
    LastName :string ;
    FirstName:string;
    MiddleName:string;
    Address:string;
    Upload :IUploadFile;
}
interface IUploadFile{
    FileName:string;
    Filetype:string;
    Value :Blob;
}
export class UploadFile implements IUploadFile {
    FileName:string;
    Filetype:string;
    Value :Blob;
}
export class NewFormDto implements INewForm{
    LastName :string ;
    FirstName:string;
    MiddleName:string;
    Address:string;
    Upload :IUploadFile;
}