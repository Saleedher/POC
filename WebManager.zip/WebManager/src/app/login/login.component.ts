import { Component, OnInit } from '@angular/core';

import {LoginDto} from './logindto' ;
import { Router } from '@angular/router';
import { AuthenticationService } from '../shared/services/authentication.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginModel :LoginDto ={EmployerCode:null,UserName:null,Password:null};
  public errorMsg : string;
  constructor(private authenticationService: AuthenticationService
               , private router: Router  ) { 
  }

  ngOnInit() {
  }
  login(){
    
    //   this.authenticationService.login(this.loginModel)
    // .subscribe(
    //   data => {
    //     let token = data;
    //     if(token != null){
    //       localStorage.setItem('accessToken', token);
            this.gotoDashboard();
    //     }else{
    //       this.errorMsg = "Please check the username and password";
    //     }
    //   }
    // );
  }
  gotoDashboard(){
    this.router.navigate(['create']);
  }
}
