interface IloginDto{
    EmployerCode :string ;
    UserName:string;
    Password:String
}
export class LoginDto implements IloginDto{
    EmployerCode :string ;
    UserName:string;
    Password:String
}