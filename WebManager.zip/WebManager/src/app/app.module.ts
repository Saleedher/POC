import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { AuthenticationService } from './shared/services/authentication.service';
import { CreateFormService } from './shared/services/createform.service';
import { FormI9Component } from './form-i9/form-i9.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    FormI9Component,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    SharedModule
  ],
  providers: [AuthenticationService,CreateFormService],
  bootstrap: [AppComponent]
})
export class AppModule { }
