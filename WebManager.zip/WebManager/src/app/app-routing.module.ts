import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ RouterModule,Routes} from '@angular/router' ;
import {LoginComponent} from './login/login.component' ;
import {FormI9Component} from  './form-i9/form-i9.component';
export const routes :Routes =[
  {path:'login',component:LoginComponent,pathMatch:'full'},
  {path: 'create', component:FormI9Component,pathMatch:'full' }
]


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
