export const constants = {
    DashboardsTokenUri: 'http://localhost:50841/api/Token',
    DashboardsPostUri : 'http://localhost:51672/api/Forms/',
};