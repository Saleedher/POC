export const constants = {
    DashboardsTokenUri: 'http://localhost:50841/api/Token',
    DashboardsPostUri : 'https://flexpool-dot-saleedher-appproject.appspot.com/api/Forms',
};