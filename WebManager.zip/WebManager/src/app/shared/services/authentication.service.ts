import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs';
import  'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpHeaders} from '@angular/common/http';
import { Router } from '@angular/router'
import {LoginDto}  from '../../login/logindto' ;
import {constants} from '../environment.config' ;
@Injectable()
export class AuthenticationService {
    public token: string;
    public handleError:string ;
    public errorMsg: string;
    constructor(private http: Http,public _router: Router) {
    }
 
    login(loginInfo :LoginDto)  {
        let apiUrl = constants.DashboardsTokenUri;
        let header = new Headers();
        header.append('Content-Type', 'application/json');
        header.append('Access-Control-Allow-Headers', '*');
        header.append('Access-Control-Allow-Headers', 'Content-Type');

        return this.http.post(apiUrl,loginInfo ,{ headers: header })
        .map( response => response.json() );

     }
 
    logout(): void {
        // clear token remove user from local storage to log user out
        this.token = null;
        localStorage.removeItem('accessToken');
        this._router.navigate(['login']);
    }

    
}