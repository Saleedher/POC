import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs';
import  'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpHeaders} from '@angular/common/http';
import { Router } from '@angular/router'
import {NewFormDto}  from '../../form-i9/newFormDto' ;
import {constants} from '../environment.config';
@Injectable()
export class CreateFormService {
    constructor(private http: Http) {
    }
    create(formInfo :NewFormDto)  {
        let apiUrl = constants.DashboardsPostUri;
        let header = new Headers();
        header.append('Content-Type', undefined);
        header.append('Access-Control-Allow-Headers', '*');
        header.append('Access-Control-Allow-Headers', 'Content-Type');
        return this.http.post(apiUrl,formInfo ,{ headers: header })
        .map( response => response.json() );

     }
}