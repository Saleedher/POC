using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;
using I9Forms.Api.Common;
using I9Forms.Api.Data;
using I9Forms.Api.Dto;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace I9Forms.Api.Controllers
{
    [Produces("application/json")]
    [EnableCors("CorsPolicy")]
    [Route("api/Forms")]
    public class FormsController : Controller
    {
        AppSettingsConfiguration Config { get; }
        readonly ILogger<FormsController> logger;
        IHostingEnvironment HostingEnvironment { get; }
        private readonly DbConnection dbConnection;

        public FormsController(AppSettingsConfiguration config, ILogger<FormsController> log, IHostingEnvironment hostingEnvironment, DbConnection dbConnection)
        {
            Config = config;
            logger = log;
            HostingEnvironment = hostingEnvironment;
            this.dbConnection = dbConnection;
        }
        [HttpPost]
        public IActionResult Post([FromBody] FormsDto request)
        {
            try
            {
                logger.LogInformation("Start Saving Data", request);
                var DataRepository = new FormsRepository(Config, HostingEnvironment,dbConnection);
                DataRepository.CreateForm(request);
                logger.LogInformation("Saved Data Successfully!!");
            }
            catch (Exception ex)
            {
                logger.LogInformation(ex.Message);
            }
            return   Json($"Uploaded Successfully."); 
        }


    }
}
