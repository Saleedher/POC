using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace I9Forms.Api.Common
{
    public class CloudSettingsConfiguration
    {
        public string StorageKey { get; set; }
        public string StorageBuketName { get; set; }
  }

}
