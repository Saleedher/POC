namespace Token.Service.Api.Dto
{
  public class TokenRequestDto
  {
    public string EmplyerCode { get; set;}
    public string UserName { get; set; }
    public string Password { get; set; }
  }
}
