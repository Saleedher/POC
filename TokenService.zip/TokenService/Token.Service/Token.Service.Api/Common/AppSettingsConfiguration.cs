using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Token.Service.Api.Common
{
  public class AppSettingsConfiguration
  {
    public AppSettingsConfiguration()
    {
      //TokenSettings = new TokenSettingsConfiguration();
    }
    public string SecurityKey { get; set; }
    public TokenSettingsConfiguration TokenSettings { get; set; }
  }
  
}
