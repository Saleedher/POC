using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Token.Service.Api.Common;
using Token.Service.Api.Dto;
namespace Token.Service.Api.Controllers
{
    [EnableCors("CorsPolicy")]
    //[Produces("application/json")]
    [Route("api/Token")]
    public class TokenController : Controller
    {
    AppSettingsConfiguration Config { get; }
    public TokenController(AppSettingsConfiguration config)
    {
      Config = config;
    }
  [HttpPost]
    public IActionResult RequestToken([FromBody] TokenRequestDto request)
    {
      if (request.EmplyerCode != string.Empty && request.UserName!=string.Empty && request.Password != string.Empty)
      {
        var claims = new[]
        {
            new Claim(ClaimTypes.Name, request.UserName)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Config.SecurityKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: Config.TokenSettings.Issuer,
            audience: Config.TokenSettings.Audience,
            claims: claims,
            expires: DateTime.Now.AddMinutes(Config.TokenSettings.Expires),
            signingCredentials: creds);

        return Ok(new
        {
          token = new JwtSecurityTokenHandler().WriteToken(token)
        });
      }

      return BadRequest("Could not verify username and password");
    }

  }
}
