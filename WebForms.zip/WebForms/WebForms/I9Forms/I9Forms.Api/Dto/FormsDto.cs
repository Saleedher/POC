using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace I9Forms.Api.Dto
{
    public class FormsDto
    {
      public string LastName { get; set; }
      public string FirstName { get; set; }
      public string MiddleName { get; set; }
      public string Address{ get; set; }
      public UploadFileDto Upload { get; set; }
  }
  public class UploadFileDto
  {
  public string FileName { get; set; }
  public string Filetype { get; set; }
  public byte[] Value { get; set; }
  }
}
