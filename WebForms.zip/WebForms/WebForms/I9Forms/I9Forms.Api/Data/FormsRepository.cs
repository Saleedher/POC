using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using I9Forms.Api.Common;
using I9Forms.Api.Dto;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace I9Forms.Api.Data
{
    public class FormsRepository
    {
        AppSettingsConfiguration Config { get; }
        IHostingEnvironment HostingEnvironment { get; }
        private readonly DbConnection dbConnection;

        public FormsRepository(AppSettingsConfiguration config, IHostingEnvironment hostingEnvironment, DbConnection dbConnection)
        {
            Config = config;
            HostingEnvironment = hostingEnvironment;
            this.dbConnection = dbConnection;
        }
        public void CreateForm(FormsDto forms)
        {
            SavePersonalInfo(forms, forms.Upload.FileName);
            SaveFile(forms.Upload);
        }
        private void SaveFile(UploadFileDto file)
        {

            var webRootPath = HostingEnvironment.WebRootPath;
            var filePath = webRootPath + "\\" + file.FileName;
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                stream.Write(file.Value, 0, file.Value.Length);
            }
            UploadFile(file.FileName, filePath);
        }
        private void SavePersonalInfo(FormsDto formsDto,string fileName)
        {
            //connectio

            using (var insertVisitCommand = dbConnection.CreateCommand())
            {
                insertVisitCommand.CommandText =
                    @"INSERT INTO NewForm (LastName,FirstName, MiddleInitial,Address,FileName,submission_date) values (@LastName,@FirstName, @MiddleInitial,@Address,@FileName,@submission_date)";

                var LastName = insertVisitCommand.CreateParameter();
                LastName.ParameterName = "@LastName";
                LastName.DbType = DbType.String;
                LastName.Value = formsDto.LastName;
                insertVisitCommand.Parameters.Add(LastName);

                var FirstName = insertVisitCommand.CreateParameter();
                FirstName.ParameterName = "@FirstName";
                FirstName.DbType = DbType.String;
                FirstName.Value = formsDto.FirstName;
                insertVisitCommand.Parameters.Add(FirstName);

                var MiddleInitial = insertVisitCommand.CreateParameter();
                MiddleInitial.ParameterName = "@MiddleInitial";
                MiddleInitial.DbType = DbType.String;
                MiddleInitial.Value = formsDto.MiddleName;
                insertVisitCommand.Parameters.Add(MiddleInitial);

                var Address = insertVisitCommand.CreateParameter();
                Address.ParameterName = "@Address";
                Address.DbType = DbType.String;
                Address.Value = formsDto.Address;
                insertVisitCommand.Parameters.Add(Address);

                var FileName = insertVisitCommand.CreateParameter();
                FileName.ParameterName = "@FileName";
                FileName.DbType = DbType.String;
                FileName.Value = fileName;
                insertVisitCommand.Parameters.Add(FileName);

                var submission_date = insertVisitCommand.CreateParameter();
                submission_date.ParameterName = "@submission_date";
                submission_date.DbType = DbType.Date;
                submission_date.Value = DateTime.Now;
                insertVisitCommand.Parameters.Add(submission_date);

                insertVisitCommand.ExecuteNonQuery();
            }
        }
        private void UploadFile(string fileName, string filePath)
        {
            //string projectId = "saleedher-appproject";
            var credential = GoogleCredential.FromFile(Config.CloudSettings.StorageKey);
            var storageClient = StorageClient.Create(credential);


            // var storage = StorageClient.Create();
            using (var fileRead = System.IO.File.OpenRead(filePath))
            {
                storageClient.UploadObject(Config.CloudSettings.StorageBuketName, fileName, null, fileRead);
            }
        }
    }
}
