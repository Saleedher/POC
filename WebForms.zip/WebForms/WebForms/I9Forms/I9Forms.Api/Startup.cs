using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;
using I9Forms.Api.Common;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;
using MySql.Data.MySqlClient;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc.Cors.Internal;
using System.Net;
using Newtonsoft.Json;

namespace I9Forms.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration, ILoggerFactory loggerFactory)
        {

            Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();
            Configuration = configuration;
            loggerFactory.AddSerilog();
        }


        public IConfiguration Configuration { get; }
        public ILoggerFactory LoggerFactory { get; }
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            var config = new AppSettingsConfiguration();
            Configuration.Bind("AppSettings", config);      //  <--- This

            services.AddSingleton(typeof(DbConnection), (IServiceProvider) =>
               InitializeDatabase());

            services.AddSingleton(config);

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                                .AllowAnyOrigin()
                                .AllowAnyMethod()
                                .WithExposedHeaders("content-disposition")
                                .AllowAnyHeader()
                                .AllowCredentials()
                                .SetPreflightMaxAge(TimeSpan.FromSeconds(3600)));
            });

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMiddleware(typeof(ErrorHandlingMiddleware));
            app.UseCors("CorsPolicy");
            app.UseMvc();
            
        }


        DbConnection InitializeDatabase()
        {
            DbConnection connection;
            string database = Configuration["AppSettings:CloudSQL:Database"];
            switch (database.ToLower())
            {
                case "formdb1":
                    connection = NewMysqlConnection();
                    break;

                default:
                    throw new ArgumentException(string.Format(
                        "Invalid database {0}.  Fix appsettings.json.",
                            database), "CloudSQL:Database");
            }
            connection.Open();
            using (var createTableCommand = connection.CreateCommand())
            {
                createTableCommand.CommandText = @"
                    CREATE TABLE IF NOT EXISTS 
                    NewForm (
                        time_stamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
                        user_ip CHAR(64)
                    )";
                createTableCommand.ExecuteNonQuery();
            }
            return connection;
        }

        DbConnection NewMysqlConnection()
        {
            // [START mysql_connection]
            var connectionString = new MySqlConnectionStringBuilder(
                Configuration["AppSettings:CloudSql:ConnectionString"])
            {
                SslMode = MySqlSslMode.Required,
                CertificateFile = Configuration["AppSettings:CloudSql:CertificateFile"],
                CertificatePassword = Configuration["AppSettings:CloudSql:CertificatePassword"]
                // Connecting to a local proxy that does not support ssl.
                //SslMode = MySqlSslMode.None,
            };
            if (string.IsNullOrEmpty(connectionString.Database))
                connectionString.Database = "FormDB1";
            DbConnection connection =
                new MySqlConnection(connectionString.ConnectionString);
            // [END mysql_connection]
            return connection;
        }
    }

    public class CorsMiddleware
    {
        private readonly RequestDelegate _next;

        public CorsMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {
            httpContext.Response.Headers.Add("Access-Control-Allow-Origin", "*");
            httpContext.Response.Headers.Add("Access-Control-Allow-Credentials", "true");
            httpContext.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type, Accept");
            httpContext.Response.Headers.Add("Access-Control-Allow-Methods", "POST,GET,PUT,PATCH,DELETE,OPTIONS");
            return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class CorsMiddlewareExtensions
    {
        public static IApplicationBuilder UseCorsMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CorsMiddleware>();
        }
    }

    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate next;

        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context /* other dependencies */)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var code = HttpStatusCode.InternalServerError; // 500 if unexpected

            var result = JsonConvert.SerializeObject(new { error = exception.Message });
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            return context.Response.WriteAsync(result);
        }
    }
}
