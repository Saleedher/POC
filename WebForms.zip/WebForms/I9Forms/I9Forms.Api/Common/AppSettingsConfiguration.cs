using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace I9Forms.Api.Common
{
  public class AppSettingsConfiguration
  {
    public AppSettingsConfiguration()
    {
      //TokenSettings = new TokenSettingsConfiguration();
    }
    public string SecurityKey { get; set; }

    public string LogPath { get; set; }

    public string ConnectionString { get; set; }

    public TokenSettingsConfiguration TokenSettings { get; set; }

    public CloudSettingsConfiguration CloudSettings  { get; set; }
}
  
}
