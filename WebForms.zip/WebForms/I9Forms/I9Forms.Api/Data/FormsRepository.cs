using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using I9Forms.Api.Common;
using I9Forms.Api.Dto;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace I9Forms.Api.Data
{
    public class FormsRepository
    {
    AppSettingsConfiguration Config { get; }
    IHostingEnvironment HostingEnvironment { get; }
    public FormsRepository(AppSettingsConfiguration config, IHostingEnvironment hostingEnvironment)
    {
      Config = config;
      HostingEnvironment = hostingEnvironment;
    }
    public void CreateForm(FormsDto forms)
    {
      SavePersonalInfo(forms);
      SaveFile(forms.Upload);
    }
    private void SaveFile(UploadFileDto file)
    {
     
      var webRootPath = HostingEnvironment.WebRootPath;
      var filePath = webRootPath + "\\" + file.FileName;
      using (var stream = new FileStream(filePath, FileMode.Create))
      {
        stream.Write(file.Value, 0, file.Value.Length);
      }
      UploadFile(file.FileName, filePath);
    }
    private void SavePersonalInfo(FormsDto forms)
    {
      //connectio
    }
    private void UploadFile(string fileName,string filePath)
    {
      //string projectId = "saleedher-appproject";
      var credential = GoogleCredential.FromFile(Config.CloudSettings.StorageKey);
      var storageClient = StorageClient.Create(credential);
      

      // var storage = StorageClient.Create();
      using (var fileRead = System.IO.File.OpenRead(filePath))
      {
        storageClient.UploadObject(Config.CloudSettings.StorageBuketName, fileName, null, fileRead);
      }
    }
  }
}
