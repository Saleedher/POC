using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using I9Forms.Api.Common;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;

namespace I9Forms.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration, ILoggerFactory loggerFactory)
        {
           
            Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();
            Configuration = configuration;
            loggerFactory.AddSerilog();
    }
    
    
        public IConfiguration Configuration { get; }
        public ILoggerFactory LoggerFactory { get; }
    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
        {
           
            var config = new AppSettingsConfiguration();
            Configuration.Bind("AppSettings", config);      //  <--- This
            services.AddSingleton(config);
            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
              builder.AllowAnyOrigin()
                     .AllowAnyHeader()
                     .AllowAnyMethod();
            }));
            services.AddMvc();
    }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc();
        }
    }
}
